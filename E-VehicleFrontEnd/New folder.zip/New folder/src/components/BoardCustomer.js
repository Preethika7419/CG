import React from "react";

const BoardCustomer = () => {
  return (
    <div className="container">
      <header className="jumbotron">
        <h3>Customer Board</h3>
      </header>
    </div>
  );
};

export default BoardCustomer;