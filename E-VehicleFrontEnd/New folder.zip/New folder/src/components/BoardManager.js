import React from "react";

const BoardManager = () => {
  return (
    <div className="container">
      <header className="jumbotron">
        <h3>Manager Board</h3>
      </header>
    </div>
  );
};

export default BoardManager;