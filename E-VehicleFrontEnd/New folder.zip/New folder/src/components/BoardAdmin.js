import React from "react";

const BoardAdmin = () => {
  return (
    <div className="container">
      <header className="jumbotron">
        <h3>Admin Board</h3>
      </header>
    </div>
  );
};
export default BoardAdmin;