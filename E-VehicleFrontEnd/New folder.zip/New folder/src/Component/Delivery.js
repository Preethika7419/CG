import React, { Component } from "react";
class Delivery extends Component {
  state = {};
  render() {
    return <p><h1>Payment on Delivery</h1></p>;
  }
}

export default Delivery;
