import React, { Component } from "react";
class HomeBg extends Component {
  state = {};
  render() {
    return (
        <div class="vehicledisplay">

    </div>

    )
    
    ;
  }
}

export default HomeBg;
