import React, { Component } from "react";

class Contact extends Component{
    state = {};
    render()
    {
        return (  
            <div>         
                <p>

                <h1>Simplest way to buy a Vehicles Online. Worldwide!!!</h1>
                <h5>Our E-Showroom was established with the aim of providing the simplest car buying & selling experience to everyone around the world.</h5>
                From researching the perfect vehicle to getting the delivery from the seller is made hassle-free with just a few clicks.<br/>
                We understand that a vehicle is one of the most expensive asset a consumer associates his lifestyle with and our platform makes sure that your investment is worth. 
                <br/>we give unbiased and elaborate information about every vehicles listed
                </p>
               
                <h1><b><i> contact details</i></b></h1>
                <p>
                    Email:evehicle2020@gmail.com <br/>
                    Contact:9876541236,8965789546
                </p>
            </div>
        );


        
    }
}
export default Contact;