import React, { Component } from "react";
class Profile extends Component {
  state = {};
  render() {
    return <p><h1>User Profile</h1></p>;
  }
}

export default Profile;
